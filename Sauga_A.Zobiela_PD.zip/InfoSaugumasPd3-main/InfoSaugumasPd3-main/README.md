# InfoSaugumasPd3
Informacijos saugumo 3 praktinio darbo algoritmas
